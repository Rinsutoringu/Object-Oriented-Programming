package question8;

// The Shape class must be abstract because the area and resize
// methods are abstract.
public abstract class Shape {
	
	// The testShape method is empty because we cannot create objects
	// from the Shape class, since it is abstract.
	public static void testShape() {
	}

}