package question8;

// The CannotResizeException class derives from the Exception class.
public class CannotResizeException extends Exception {
	
}