package question8;

public class BadRadiusException extends Exception{
   
}