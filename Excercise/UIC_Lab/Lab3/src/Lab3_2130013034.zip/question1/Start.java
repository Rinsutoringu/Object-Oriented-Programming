// Author: RinChord
// Date: 2025/3/6
// Description: Student class for question 1

package question1;

public class Start {
    public static void main(String[] args) {
        Student.testStudent(2130013034);
    }
}
