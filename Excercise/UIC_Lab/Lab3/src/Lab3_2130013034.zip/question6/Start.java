// Author: RinChord
// Date: 2025/3/6
// Description: Student class for question 6

package question6;

public class Start {
    public static void main(String[] args) {
        Student.testStudent();
    }
}
