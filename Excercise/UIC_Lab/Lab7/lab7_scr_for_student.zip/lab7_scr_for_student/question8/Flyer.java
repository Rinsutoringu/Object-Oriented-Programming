package question8;

public interface Flyer {

}