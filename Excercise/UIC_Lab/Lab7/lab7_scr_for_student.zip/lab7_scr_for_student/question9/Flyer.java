package question9;

public interface Flyer {
    
    }