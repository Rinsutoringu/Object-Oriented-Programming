package question2;

// The Animal class must be abstract because its two methods getLegs
// and canFly (below) are abstract.
public abstract class Animal {
	
	public static void testAnimal() {
		// Animal a = new Animal("Unknown"); // This does not work!
	}
}