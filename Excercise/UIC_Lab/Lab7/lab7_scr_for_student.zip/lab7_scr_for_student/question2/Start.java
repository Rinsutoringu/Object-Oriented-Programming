package question2;

public class Start {
	public static void main(String[] args) {
		Animal.testAnimal();
		Dog.testDog();
		// No system tests: the Dog class does not use any other class.
	}
}