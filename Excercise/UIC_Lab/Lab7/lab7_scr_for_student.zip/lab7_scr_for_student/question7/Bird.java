package question7;

// The class Bird derives from the class Animal.
// The class must be abstract because it does not have any code for
// the canFly method (see below).
public abstract class Bird extends Animal implements Flyer{

	public static void testBird() {
		// Bird b = new Bird("Twitter", 3); // This does not work!
	}
}