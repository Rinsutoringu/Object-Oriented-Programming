package question7;

public interface Flyer {
   
}