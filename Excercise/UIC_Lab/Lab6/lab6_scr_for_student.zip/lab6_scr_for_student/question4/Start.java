package question4;
public class Start {
	public static void main(String[] args) {
		System.out.println("testShape");
		Shape.testShape();
		System.out.println("\ntestCircle");
		Circle.testCircle();
		System.out.println("\ntestRectangle");
		Rectangle.testRectangle();
		System.out.println("\ntestManyShapes");
		ManyShapes.testManyShapes(); 
	}
}