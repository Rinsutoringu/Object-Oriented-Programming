package question1;

public class Start {
	public static void main(String[] args) {
		// run the tests;
		Code.testCode();
		Assignment.testAssignment();
		Student.testStudent();
		Teacher.testTeacher();
	}
}