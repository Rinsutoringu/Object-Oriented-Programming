package question1;

public class HelloWorld {
	
	/* The HelloWorld Program
	 * -------------------
	 * Illustrates a simple program displaying
	 * a message.
	 */
	
	public static void main (String[] args) {
	System.out.println("HelloWorld!");
	}
}
