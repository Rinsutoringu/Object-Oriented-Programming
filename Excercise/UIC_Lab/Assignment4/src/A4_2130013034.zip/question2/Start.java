package question2;

public class Start {
	public static void main(String[] args) {
		// NULL
	}

}
