package question2;

public interface Movable {
    boolean start();
    void stop();
}
