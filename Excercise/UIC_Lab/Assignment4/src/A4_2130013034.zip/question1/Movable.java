package question1;

public interface Movable {
    boolean start();
    void stop();
}
