package question3;

public interface Movable {

}
