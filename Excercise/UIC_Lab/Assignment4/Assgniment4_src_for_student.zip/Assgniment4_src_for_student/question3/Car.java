package question3;

public abstract class Car implements Movable {
	
}
